'use client'

import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Landing from './components/Landing'
import Dashboard from './components/Dashboard'
import gsap from 'gsap'

function App() {
  const [isEntering, setIsEntering] = useState(false)
  const [showDashboard, setShowDashboard] = useState(false)
  const [transitionComplete, setTransitionComplete] = useState(false)

  const handleEnter = () => {
    setIsEntering(true)

    // GSAP animation for cinematic transition
    gsap.timeline()
      .to('body', {
        duration: 0.5,
        backgroundColor: '#0a0e27',
      })
      .to(
        '.transition-overlay',
        {
          duration: 1.2,
          scaleY: 1,
          ease: 'power2.inOut',
        },
        0.3
      )
      .to(
        '.transition-overlay',
        {
          duration: 1.2,
          scaleY: 0,
          ease: 'power2.inOut',
          delay: 0.8,
        }
      )

    setTimeout(() => {
      setShowDashboard(true)
      setTransitionComplete(true)
    }, 1500)
  }

  return (
    <div className="w-full h-screen overflow-hidden bg-dark">
      {/* Transition Overlay */}
      <motion.div
        className="transition-overlay fixed inset-0 bg-gradient-to-b from-neon-cyan via-neon-purple to-dark
          z-50 origin-top pointer-events-none"
        initial={{ scaleY: 0 }}
        transition={{ duration: 0.3 }}
      ></motion.div>

      <AnimatePresence mode="wait">
        {!showDashboard ? (
          <motion.div
            key="landing"
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Landing onEnter={handleEnter} />
          </motion.div>
        ) : (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Dashboard transitionComplete={transitionComplete} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Background Gradient Blob */}
      <motion.div
        className="fixed top-1/4 right-0 w-96 h-96 bg-neon-cyan/5 rounded-full blur-3xl pointer-events-none"
        animate={{
          y: [0, 50, 0],
          x: [0, -30, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      ></motion.div>

      <motion.div
        className="fixed bottom-1/4 left-0 w-96 h-96 bg-neon-purple/5 rounded-full blur-3xl pointer-events-none"
        animate={{
          y: [0, -50, 0],
          x: [0, 30, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      ></motion.div>
    </div>
  )
}

export default App
